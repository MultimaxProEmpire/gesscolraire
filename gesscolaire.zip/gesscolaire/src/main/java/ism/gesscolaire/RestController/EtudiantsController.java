package ism.gesscolaire.RestController;

import ism.gesscolaire.entities.Etudiants;
import ism.gesscolaire.repositories.EtudiantRepositories;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/etudiants")
public class EtudiantsController {

    @Autowired
    private EtudiantRepositories etudiantsRepository;

    @GetMapping
    public List<Etudiants> getAllEtudiants() {
        return etudiantsRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Etudiants> getEtudiantById(@PathVariable Long id) {
        Optional<Etudiants> etudiant = etudiantsRepository.findById(id);
        return etudiant.map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Etudiants createEtudiant(@RequestBody Etudiants etudiant) {
        return etudiantsRepository.save(etudiant);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Etudiants> updateEtudiant(@PathVariable Long id, @RequestBody Etudiants etudiantDetails) {
        Optional<Etudiants> optionalEtudiant = etudiantsRepository.findById(id);
        if (optionalEtudiant.isPresent()) {
            Etudiants etudiant = optionalEtudiant.get();
            etudiant.setNomComplet(etudiantDetails.getNomComplet());
            etudiant.setTuteur(etudiantDetails.getTuteur());
            etudiant.setDateInscription(etudiantDetails.getDateInscription());
            etudiant.setEmail(etudiantDetails.getEmail());
            etudiant.setPassword(etudiantDetails.getPassword());
            etudiant.setClasse(etudiantDetails.getClasse());
            return ResponseEntity.ok(etudiantsRepository.save(etudiant));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEtudiant(@PathVariable Long id) {
        Optional<Etudiants> optionalEtudiant = etudiantsRepository.findById(id);
        if (optionalEtudiant.isPresent()) {
            etudiantsRepository.deleteById(id);
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    // Autres méthodes si nécessaire

}