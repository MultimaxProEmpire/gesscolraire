package ism.gesscolaire.repositories;
import ism.gesscolaire.entities.Classe;
import ism.gesscolaire.entities.Etudiants;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface EtudiantRepositories extends JpaRepository<Etudiants,Long> {

    Page<Etudiants> findAll(Pageable pageable);
    Page<Etudiants> findByDateInscriptionAndClasse(LocalDate dateInscription, Classe classe,Pageable pageable);

    List<Etudiants> findByClasse(Classe classe);
}
