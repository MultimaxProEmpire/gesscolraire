package ism.gesscolaire.controllers;

import ism.gesscolaire.entities.Classe;
import ism.gesscolaire.entities.Etudiants;
import ism.gesscolaire.repositories.ClasseRepositories;
import ism.gesscolaire.repositories.EtudiantRepositories;
import org.apache.coyote.Request;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.ui.Model;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;



@Controller
public class InscriptionController {

    @Autowired
    private ClasseRepositories classeRepositories;
    @Autowired
    private EtudiantRepositories etudiantRepositories;



    @GetMapping("/inscription")
    public String inscription(
            Model model
    ){
        model.addAttribute("listeClasse",classeRepositories.findAll());
        return "Inscriptions";
    }

    @PostMapping("/inscription")
    public String insrireEtudiant(
            Model model,
            @RequestParam("nom") String nom,
            @RequestParam("tuteur") String tuteur,
            @RequestParam("email") String email,
            @RequestParam("password") String password,
            @RequestParam("classe") String classe

    ){
        Classe classes = classeRepositories.findByLibelle(classe);
        if (classes!=null) {
        Etudiants etudiants = new Etudiants();
        etudiants.setNomComplet(nom);
        etudiants.setEmail(email);
        etudiants.setTuteur(tuteur);
        etudiants.setPassword(password);
        etudiants.setDateInscription(LocalDate.of(2023,06,9));
        etudiants.setClasse(classes);
        etudiantRepositories.save(etudiants);
        }else{
            return "redirect:/inscription";
        }
        return "redirect:/liste-inscrits";
    }
    @GetMapping("/liste-inscrits")
    public String listeInscrit(Model model,
                               @RequestParam(name = "page",defaultValue = "0") int page,
                               @RequestParam(name = "size",defaultValue = "10") int size
    ){
        Page<Etudiants> listes = etudiantRepositories.findAll(PageRequest.of(page,size));
        model.addAttribute("listes",listes.getContent());
        model.addAttribute("pages",new int[listes.getTotalPages()]);
        model.addAttribute("currentPage",page);
        model.addAttribute("listeClasse",classeRepositories.findAll());

        return "Inscrits";
    }

    @GetMapping("liste-inscrits/rechercher")
    public String rechercherEtudiants(Model model,
                                      @RequestParam(name = "page",defaultValue = "0") int page,
                                      @RequestParam(name = "size",defaultValue = "10") int size,
                                      @RequestParam(name="classe") String classe,
                                      @RequestParam(name = "date") LocalDate date

    ){
        Classe classes = classeRepositories.findByLibelle(classe);
        Page<Etudiants> listes = etudiantRepositories.findByDateInscriptionAndClasse(date,classes,PageRequest.of(page,size));
        model.addAttribute("listes",listes.getContent());
        model.addAttribute("pages",new int[listes.getTotalPages()]);
        model.addAttribute("currentPage",page);
        model.addAttribute("listeClasse",classeRepositories.findAll());
        return "recherche";
    }


}
